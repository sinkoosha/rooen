import React from "react";

const auth = React.createContext();

export default auth;
