import React from "react";
import "./index.css";

function Index() {
  return <div className="indexHome">sddsf</div>;
}

export default Index;
